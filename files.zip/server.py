"""
╔══════════════════════════════════════════════════════════════════╗
║   SENTINEL — Virtual Fence + Human Detection Server             ║
║   Python 3.14 + MediaPipe 0.10.32                               ║
╠══════════════════════════════════════════════════════════════════╣
║   • Draggable virtual fence line (set from browser UI)          ║
║   • Human turns RED when they cross the fence                   ║
║   • BREACH alert + auto-capture on violation                    ║
║   • Fence can be horizontal, vertical, or diagonal              ║
║   • Safe zone shown in green, danger zone shown in red          ║
╚══════════════════════════════════════════════════════════════════╝

INSTALL:
    pip install flask flask-socketio opencv-python mediapipe numpy eventlet

RUN:
    python server.py
    Open: http://localhost:5000
"""

import cv2
import numpy as np
import math
import time
import os
import sys
import threading
import base64
import traceback
import urllib.request
import tempfile
from datetime import datetime
from collections import deque

import mediapipe as mp
from flask import Flask, render_template, Response
from flask_socketio import SocketIO

# ── MediaPipe 0.10+ Tasks API ─────────────────────────────────────
BaseOptions           = mp.tasks.BaseOptions
PoseLandmarker        = mp.tasks.vision.PoseLandmarker
PoseLandmarkerOptions = mp.tasks.vision.PoseLandmarkerOptions
PoseLandmarkerResult  = mp.tasks.vision.PoseLandmarkerResult
VisionRunningMode     = mp.tasks.vision.RunningMode

print(f"[SERVER] MediaPipe {mp.__version__}  |  Python {sys.version.split()[0]}")

# ══════════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════════
CAMERA_INDEX     = 0
FRAME_W          = 640
FRAME_H          = 480
CAPTURES_DIR     = "./static/captures"
STREAM_QUALITY   = 78

MIN_VIS          = 0.55
MIN_SHAPE        = 0.60
MIN_SKIN         = 0.04
MIN_MOTION       = 0.012
CONFIRM_FRAMES   = 3
CAPTURE_COOLDOWN = 3.0

# Breach capture cooldown (separate from normal capture)
BREACH_COOLDOWN  = 2.0

MODEL_PATH = os.path.join(tempfile.gettempdir(), "pose_landmarker_lite.task")
MODEL_URL  = (
    "https://storage.googleapis.com/mediapipe-models/"
    "pose_landmarker/pose_landmarker_lite/float16/latest/"
    "pose_landmarker_lite.task"
)

os.makedirs(CAPTURES_DIR, exist_ok=True)

# ── Flask & SocketIO ──────────────────────────────────────────────
app = Flask(__name__)
app.config["SECRET_KEY"] = "sentinel_fence_2025"
sio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# ══════════════════════════════════════════════════════════════════
#  VIRTUAL FENCE STATE
#  fence_line = {"x1":0.1,"y1":0.5,"x2":0.9,"y2":0.5}
#  All values normalized 0.0–1.0 relative to frame size
#  "safe_side" = "above" | "below" | "left" | "right"
#    — which side of the line is the SAFE (green) zone
# ══════════════════════════════════════════════════════════════════
fence_lock = threading.Lock()
fence_state = {
    "enabled":    True,
    "x1":         0.05,   # default: horizontal line across middle
    "y1":         0.55,
    "x2":         0.95,
    "y2":         0.55,
    "safe_side":  "above",   # "above" | "below" | "left" | "right"
    "sensitivity": "feet",   # "feet" | "hips" | "any"
}

# ── Shared detection state ────────────────────────────────────────
_lock  = threading.Lock()
shared = {
    "frame_jpeg":       None,
    "human_detected":   False,
    "breach_detected":  False,
    "shape_score":      0.0,
    "skin_score":       0.0,
    "motion_score":     0.0,
    "kp_visible":       0,
    "fps":              0.0,
    "total_captures":   0,
    "total_breaches":   0,
    "reject_reason":    "Starting...",
    "keypoints":        [],
    "connections":      [],
    "captures_list":    [],
    "breach_list":      [],
    "person_side":      "unknown",  # which side of fence person is on
    "running":          False,
}

# ══════════════════════════════════════════════════════════════════
#  MODEL DOWNLOAD
# ══════════════════════════════════════════════════════════════════
def ensure_model() -> None:
    if os.path.exists(MODEL_PATH):
        return
    print("[INFO] Downloading pose model (one-time ~4MB)...")
    try:
        urllib.request.urlretrieve(MODEL_URL, MODEL_PATH)
        print(f"[INFO] Saved → {MODEL_PATH}")
    except Exception as e:
        print(f"[ERROR] Download failed: {e}")
        sys.exit(1)

# ══════════════════════════════════════════════════════════════════
#  20 KEYPOINTS
# ══════════════════════════════════════════════════════════════════
KP = {
    "nose":0,"left_eye":2,"right_eye":5,"left_ear":7,"right_ear":8,
    "left_shoulder":11,"right_shoulder":12,"left_elbow":13,"right_elbow":14,
    "left_wrist":15,"right_wrist":16,"left_hip":23,"right_hip":24,
    "left_knee":25,"right_knee":26,"left_ankle":27,"right_ankle":28,
    "left_heel":29,"right_heel":30,"left_foot":31,
}

SKELETON = [
    ("nose","left_eye"),    ("nose","right_eye"),
    ("left_eye","left_ear"),("right_eye","right_ear"),
    ("left_shoulder","right_shoulder"),
    ("left_shoulder","left_elbow"),  ("left_elbow","left_wrist"),
    ("right_shoulder","right_elbow"),("right_elbow","right_wrist"),
    ("left_shoulder","left_hip"),    ("right_shoulder","right_hip"),
    ("left_hip","right_hip"),
    ("left_hip","left_knee"),        ("left_knee","left_ankle"),
    ("right_hip","right_knee"),      ("right_knee","right_ankle"),
    ("left_ankle","left_heel"),      ("right_ankle","right_heel"),
    ("left_heel","left_foot"),       ("right_heel","left_foot"),
]

def part_of(name: str) -> str:
    if name in {"nose","left_eye","right_eye","left_ear","right_ear"}: return "head"
    if name in {"left_shoulder","right_shoulder","left_hip","right_hip"}: return "torso"
    if "elbow" in name or "wrist" in name: return "arms"
    return "legs"

# ══════════════════════════════════════════════════════════════════
#  MATH
# ══════════════════════════════════════════════════════════════════
def dist(p1, p2):
    return math.hypot(p1[0]-p2[0], p1[1]-p2[1])

def angle_at(a, b, c):
    ba=(a[0]-b[0],a[1]-b[1]); bc=(c[0]-b[0],c[1]-b[1])
    n=math.sqrt(ba[0]**2+ba[1]**2)*math.sqrt(bc[0]**2+bc[1]**2)
    if n<1e-6: return 90.0
    return math.degrees(math.acos(max(-1.0,min(1.0,(ba[0]*bc[0]+ba[1]*bc[1])/n))))

def point_side_of_line(px, py, x1, y1, x2, y2) -> float:
    """
    Returns the signed cross-product.
    Positive = left of line direction (x1,y1)→(x2,y2)
    Negative = right of line direction
    Zero     = on the line
    """
    return (x2-x1)*(py-y1) - (y2-y1)*(px-x1)

# ══════════════════════════════════════════════════════════════════
#  FENCE BREACH DETECTION
# ══════════════════════════════════════════════════════════════════
def check_fence_breach(kpts: dict) -> tuple[bool, str]:
    """
    Returns (breach: bool, side: str)
    Checks whether person's anchor points crossed the fence line.

    sensitivity modes:
      "feet"  — uses ankles/heels (most common for floor fences)
      "hips"  — uses hip midpoint (for barrier fences)
      "any"   — any keypoint crossing triggers breach
    """
    with fence_lock:
        if not fence_state["enabled"]:
            return False, "unknown"
        x1  = fence_state["x1"]
        y1  = fence_state["y1"]
        x2  = fence_state["x2"]
        y2  = fence_state["y2"]
        safe = fence_state["safe_side"]
        sens = fence_state["sensitivity"]

    # Choose which keypoints to test based on sensitivity
    if sens == "feet":
        test_names = ["left_ankle","right_ankle","left_heel","right_heel","left_foot"]
    elif sens == "hips":
        test_names = ["left_hip","right_hip","left_knee","right_knee"]
    else:  # "any"
        test_names = list(KP.keys())

    # Compute sign for the safe side using a reference point in the safe zone
    # safe_side defines which side of the line is considered safe
    # We compute the expected sign based on the safe_side setting
    if safe == "above":
        # A point clearly "above" the line: midpoint x, very small y
        ref_x, ref_y = (x1+x2)/2, 0.01
    elif safe == "below":
        ref_x, ref_y = (x1+x2)/2, 0.99
    elif safe == "left":
        ref_x, ref_y = 0.01, (y1+y2)/2
    else:  # "right"
        ref_x, ref_y = 0.99, (y1+y2)/2

    safe_sign = point_side_of_line(ref_x, ref_y, x1, y1, x2, y2)
    if safe_sign == 0:
        safe_sign = 1.0  # fallback

    # Test each anchor keypoint
    breach_points = []
    safe_points   = []

    for name in test_names:
        pt = kpts.get(name)
        if pt is None:
            continue
        cross = point_side_of_line(pt[0], pt[1], x1, y1, x2, y2)
        if cross == 0:
            continue
        same_side = (cross > 0) == (safe_sign > 0)
        if same_side:
            safe_points.append(name)
        else:
            breach_points.append(name)

    if not breach_points and not safe_points:
        return False, "unknown"

    # Determine overall side by majority
    if len(breach_points) > len(safe_points):
        return True, "breach"
    return False, "safe"

# ══════════════════════════════════════════════════════════════════
#  SHAPE SCORE
# ══════════════════════════════════════════════════════════════════
def compute_shape_score(kpts: dict) -> float:
    s: list[float] = []
    g=kpts.get; ls,rs=g("left_shoulder"),g("right_shoulder"); lh,rh=g("left_hip"),g("right_hip")
    if ls and rs and lh and rh:
        r=dist(ls,rs)/(dist(lh,rh)+1e-6); s.append(1.0 if 0.65<=r<=1.85 else 0.0)
        mid_s=((ls[0]+rs[0])/2,(ls[1]+rs[1])/2); mid_h=((lh[0]+rh[0])/2,(lh[1]+rh[1])/2)
        s.append(1.0 if 0.75<=dist(mid_s,mid_h)/(dist(ls,rs)+1e-6)<=3.2 else 0.0)
    for n3 in[("left_shoulder","left_elbow","left_wrist"),("right_shoulder","right_elbow","right_wrist")]:
        pts=[g(n) for n in n3]
        if all(pts):
            s.append(1.0 if 0.55<=dist(pts[0],pts[1])/(dist(pts[1],pts[2])+1e-6)<=1.65 else 0.15)
            s.append(1.0 if 18<=angle_at(*pts)<=176 else 0.05)
    for n3 in[("left_hip","left_knee","left_ankle"),("right_hip","right_knee","right_ankle")]:
        pts=[g(n) for n in n3]
        if all(pts):
            s.append(1.0 if 22<=angle_at(*pts)<=179 else 0.05)
            s.append(1.0 if 0.55<=dist(pts[0],pts[1])/(dist(pts[1],pts[2])+1e-6)<=1.65 else 0.1)
    nose=g("nose")
    if nose and ls and rs: s.append(1.0 if nose[1]<(ls[1]+rs[1])/2 else 0.0)
    all_pts=[v for v in kpts.values() if v]
    if len(all_pts)>=6:
        xs=[p[0] for p in all_pts]; ys=[p[1] for p in all_pts]
        s.append(1.0 if 0.12<=(max(xs)-min(xs))/(max(ys)-min(ys)+1e-6)<=0.90 else 0.0)
    return sum(s)/len(s) if s else 0.0

# ══════════════════════════════════════════════════════════════════
#  SKIN RATIO
# ══════════════════════════════════════════════════════════════════
def skin_ratio(frame_bgr: np.ndarray, kpts: dict) -> float:
    fw,fh=frame_bgr.shape[1],frame_bgr.shape[0]; regions=[]
    for name in["nose","left_wrist","right_wrist","left_ear","right_ear"]:
        pt=kpts.get(name)
        if pt:
            cx,cy=int(pt[0]*fw),int(pt[1]*fh); r=22
            roi=frame_bgr[max(0,cy-r):cy+r,max(0,cx-r):cx+r]
            if roi.size>0: regions.append(roi)
    if not regions: return 0.0
    combined=np.vstack([r.reshape(-1,3) for r in regions])
    ycrcb=cv2.cvtColor(combined.reshape(1,-1,3),cv2.COLOR_BGR2YCrCb)[0]
    cr,cb=ycrcb[:,1].astype(float),ycrcb[:,2].astype(float)
    return float(((cr>=133)&(cr<=173)&(cb>=77)&(cb<=127)).sum())/max(1,len(cr))

# ══════════════════════════════════════════════════════════════════
#  MOTION DETECTOR
# ══════════════════════════════════════════════════════════════════
class MotionDetector:
    def __init__(self):
        self._prev=None; self._scores=deque(maxlen=6)
    def update(self,gray):
        if self._prev is None: self._prev=gray.copy(); return 0.0
        s=float(cv2.absdiff(self._prev,gray).mean())/255.0
        self._scores.append(s); self._prev=gray.copy()
        return float(np.mean(self._scores))
    def reset(self): self._prev=None; self._scores.clear()

# ══════════════════════════════════════════════════════════════════
#  DRAWING — draws skeleton + fence on the OpenCV frame
# ══════════════════════════════════════════════════════════════════
def draw_fence_on_frame(frame: np.ndarray) -> None:
    """Draw the virtual fence line and zone shading on OpenCV frame."""
    with fence_lock:
        if not fence_state["enabled"]:
            return
        x1n, y1n = fence_state["x1"], fence_state["y1"]
        x2n, y2n = fence_state["x2"], fence_state["y2"]
        safe      = fence_state["safe_side"]

    h, w = frame.shape[:2]
    x1, y1 = int(x1n*w), int(y1n*h)
    x2, y2 = int(x2n*w), int(y2n*h)

    # ── Zone shading (semi-transparent)
    overlay = frame.copy()

    # Draw danger zone shading (red) on the breach side
    # We fill the whole frame red then overwrite with green on safe side
    # using the fence line as a dividing mask
    pts_full = np.array([[0,0],[w,0],[w,h],[0,h]], dtype=np.int32)

    # Create mask: safe side = green, breach side = red
    mask = np.zeros((h, w), dtype=np.uint8)
    # Draw the fence line as a polygon boundary
    fence_pts = np.array([[x1,y1],[x2,y2],[x2,h],[x1,h]], dtype=np.int32)

    if safe in ("above",):
        # Safe zone = above fence line → fill below with red
        danger_pts = np.array([[0,y1],[w,y2],[w,h],[0,h]], dtype=np.int32)
        cv2.fillPoly(overlay, [danger_pts], (0, 0, 180))
        safe_pts   = np.array([[0,0],[w,0],[w,y2],[0,y1]], dtype=np.int32)
        cv2.fillPoly(overlay, [safe_pts],   (0, 140, 0))
    elif safe == "below":
        danger_pts = np.array([[0,0],[w,0],[w,y2],[0,y1]], dtype=np.int32)
        cv2.fillPoly(overlay, [danger_pts], (0, 0, 180))
        safe_pts   = np.array([[0,y1],[w,y2],[w,h],[0,h]], dtype=np.int32)
        cv2.fillPoly(overlay, [safe_pts],   (0, 140, 0))
    elif safe == "left":
        danger_pts = np.array([[x1,0],[w,0],[w,h],[x2,h]], dtype=np.int32)
        cv2.fillPoly(overlay, [danger_pts], (0, 0, 180))
        safe_pts   = np.array([[0,0],[x1,0],[x2,h],[0,h]], dtype=np.int32)
        cv2.fillPoly(overlay, [safe_pts],   (0, 140, 0))
    else:  # right
        danger_pts = np.array([[0,0],[x1,0],[x2,h],[0,h]], dtype=np.int32)
        cv2.fillPoly(overlay, [danger_pts], (0, 0, 180))
        safe_pts   = np.array([[x1,0],[w,0],[w,h],[x2,h]], dtype=np.int32)
        cv2.fillPoly(overlay, [safe_pts],   (0, 140, 0))

    cv2.addWeighted(overlay, 0.18, frame, 0.82, 0, frame)

    # ── Fence line (thick dashed yellow/white)
    # Draw dashes along the fence line
    total_len = math.hypot(x2-x1, y2-y1)
    dash_len  = 18
    gap_len   = 10
    steps     = max(1, int(total_len / (dash_len + gap_len)))
    for i in range(steps):
        t_start = i * (dash_len + gap_len) / max(total_len, 1)
        t_end   = t_start + dash_len / max(total_len, 1)
        t_end   = min(t_end, 1.0)
        sx = int(x1 + (x2-x1)*t_start)
        sy = int(y1 + (y2-y1)*t_start)
        ex = int(x1 + (x2-x1)*t_end)
        ey = int(y1 + (y2-y1)*t_end)
        cv2.line(frame, (sx,sy), (ex,ey), (0,255,255), 4, cv2.LINE_AA)
        cv2.line(frame, (sx,sy), (ex,ey), (255,255,0), 2, cv2.LINE_AA)

    # Fence endpoints (handles)
    for px, py in [(x1,y1),(x2,y2)]:
        cv2.circle(frame, (px,py), 8, (0,255,255), -1, cv2.LINE_AA)
        cv2.circle(frame, (px,py), 8, (255,255,255), 2, cv2.LINE_AA)

    # Fence label
    mid_x = (x1+x2)//2
    mid_y = (y1+y2)//2
    cv2.putText(frame, "VIRTUAL FENCE", (mid_x-60, mid_y-12),
                cv2.FONT_HERSHEY_DUPLEX, 0.5, (0,255,255), 1, cv2.LINE_AA)

    # Zone labels
    if safe == "above":
        cv2.putText(frame, "SAFE ZONE",   (12, 30),  cv2.FONT_HERSHEY_PLAIN, 1.2, (80,255,80),  1)
        cv2.putText(frame, "DANGER ZONE", (12, h-12),cv2.FONT_HERSHEY_PLAIN, 1.2, (80,80,255),  1)
    elif safe == "below":
        cv2.putText(frame, "DANGER ZONE", (12, 30),  cv2.FONT_HERSHEY_PLAIN, 1.2, (80,80,255),  1)
        cv2.putText(frame, "SAFE ZONE",   (12, h-12),cv2.FONT_HERSHEY_PLAIN, 1.2, (80,255,80),  1)
    elif safe == "left":
        cv2.putText(frame, "SAFE",   (12, h//2),     cv2.FONT_HERSHEY_PLAIN, 1.2, (80,255,80),  1)
        cv2.putText(frame, "DANGER", (w-80, h//2),   cv2.FONT_HERSHEY_PLAIN, 1.2, (80,80,255),  1)
    else:
        cv2.putText(frame, "DANGER", (12, h//2),     cv2.FONT_HERSHEY_PLAIN, 1.2, (80,80,255),  1)
        cv2.putText(frame, "SAFE",   (w-60, h//2),   cv2.FONT_HERSHEY_PLAIN, 1.2, (80,255,80),  1)


def draw_skeleton(frame: np.ndarray, kpts: dict,
                  breach: bool, shape_score: float) -> None:
    """Draw the human skeleton. Red when in breach, green when safe."""
    h, w = frame.shape[:2]

    def px(name):
        p = kpts.get(name)
        return (int(p[0]*w), int(p[1]*h)) if p else None

    # Color scheme: red = breach, normal colors = safe
    def seg_color(part):
        if breach:
            return (50, 50, 255)   # red (BGR)
        colors = {"head":(100,220,255),"torso":(255,200,80),
                  "arms":(80,255,150),"legs":(200,100,255)}
        return colors.get(part, (200,200,200))

    # Torso fill
    corners = [px(n) for n in
               ["left_shoulder","right_shoulder","right_hip","left_hip"]]
    if all(corners):
        ov = frame.copy()
        fill_col = (20,20,120) if breach else (20,80,40)
        cv2.fillPoly(ov, [np.array(corners)], fill_col)
        cv2.addWeighted(ov, 0.30, frame, 0.70, 0, frame)

    # Skeleton lines
    for (a_name, b_name) in SKELETON:
        pa, pb = px(a_name), px(b_name)
        if pa and pb:
            col = seg_color(part_of(a_name))
            cv2.line(frame, pa, pb, col, 3, cv2.LINE_AA)

    # Keypoint dots
    for i, (name, _) in enumerate(KP.items()):
        pt = px(name)
        if not pt: continue
        col = seg_color(part_of(name))
        cv2.circle(frame, pt, 9, (255,255,255), 1, cv2.LINE_AA)
        cv2.circle(frame, pt, 5, col, -1, cv2.LINE_AA)
        cv2.putText(frame, str(i+1), (pt[0]+7,pt[1]-5),
                    cv2.FONT_HERSHEY_PLAIN, 0.65, col, 1, cv2.LINE_AA)

    # Head circle
    nose_pt = px("nose")
    le_pt   = px("left_ear")
    re_pt   = px("right_ear")
    if nose_pt and le_pt and re_pt:
        hr  = max(10, int(math.hypot(le_pt[0]-re_pt[0], le_pt[1]-re_pt[1])*0.72))
        ov2 = frame.copy()
        head_fill = (20,20,80) if breach else (60,50,20)
        cv2.circle(ov2, nose_pt, hr, head_fill, -1)
        cv2.addWeighted(ov2, 0.22, frame, 0.78, 0, frame)
        head_col = (80,80,255) if breach else (100,220,255)
        cv2.circle(frame, nose_pt, hr, head_col, 2, cv2.LINE_AA)

    # Breach warning overlay
    if breach:
        ov3 = frame.copy()
        cv2.rectangle(ov3, (0,0), (w,h), (0,0,255), -1)
        cv2.addWeighted(ov3, 0.10, frame, 0.90, 0, frame)
        cv2.rectangle(frame, (2,2), (w-2,h-2), (0,0,255), 3)
        cv2.putText(frame, "⚠ FENCE BREACH!", (w//2-120, 72),
                    cv2.FONT_HERSHEY_DUPLEX, 0.9, (0,0,255), 2, cv2.LINE_AA)


# ══════════════════════════════════════════════════════════════════
#  LANDMARK EXTRACTOR
# ══════════════════════════════════════════════════════════════════
def extract_kpts(result: PoseLandmarkerResult) -> dict:
    if not result.pose_landmarks or len(result.pose_landmarks)==0:
        return {}
    lms = result.pose_landmarks[0]
    kpts: dict = {}
    for name,idx in KP.items():
        if idx<len(lms):
            lm=lms[idx]; vis=getattr(lm,"visibility",1.0)
            if vis>=MIN_VIS: kpts[name]=(lm.x,lm.y)
    return kpts

# ══════════════════════════════════════════════════════════════════
#  DETECTION THREAD
# ══════════════════════════════════════════════════════════════════
def detection_loop() -> None:
    ensure_model()

    options = PoseLandmarkerOptions(
        base_options=BaseOptions(model_asset_path=MODEL_PATH),
        running_mode=VisionRunningMode.VIDEO,
        num_poses=1,
        min_pose_detection_confidence=0.5,
        min_pose_presence_confidence=0.5,
        min_tracking_confidence=0.5,
    )
    landmarker = PoseLandmarker.create_from_options(options)

    def open_cam():
        for _ in range(5):
            c=cv2.VideoCapture(CAMERA_INDEX)
            if c.isOpened():
                c.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_W)
                c.set(cv2.CAP_PROP_FRAME_HEIGHT,FRAME_H)
                c.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                return c
            time.sleep(0.5)
        return None

    cap = open_cam()
    if not cap:
        with _lock: shared["reject_reason"]="Camera not found"
        return

    motion         = MotionDetector()
    fps_t          = time.time()
    fps_c          = 0
    fps_val        = 0.0
    conf_cnt       = 0
    last_cap       = 0.0
    last_breach_cap= 0.0
    total          = 0
    total_breaches = 0
    cap_list: list[str]    = []
    breach_list: list[str] = []

    with _lock: shared["running"] = True
    print("[SERVER] Detection loop with virtual fence started")

    while True:
        try:
            ret, frame = cap.read()
            if not ret or frame is None:
                cap.release(); time.sleep(0.5); cap=open_cam(); motion.reset(); continue

            fps_c += 1
            if fps_c >= 20:
                fps_val = fps_c/(time.time()-fps_t+1e-6); fps_c=0; fps_t=time.time()

            gray         = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            motion_score = motion.update(gray)

            rgb      = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
            ts_ms    = int(time.time()*1000)
            result   = landmarker.detect_for_video(mp_image, ts_ms)
            kpts     = extract_kpts(result)
            visible  = len(kpts)

            human=False; shape_s=0.0; skin_s=0.0; reject="No pose"
            breach=False; person_side="unknown"
            kp_list=[]; conn_list=[]

            if visible >= 8:
                shape_s = compute_shape_score(kpts)
                skin_s  = skin_ratio(frame, kpts)

                if shape_s < MIN_SHAPE:       reject = f"Shape {shape_s:.0%}"
                elif skin_s < MIN_SKIN:        reject = f"No skin ({skin_s:.0%})"
                elif motion_score < MIN_MOTION: reject = "Static object"
                else:
                    human = True
                    reject = ""
                    # ── CHECK FENCE BREACH
                    breach, person_side = check_fence_breach(kpts)

                for i,(name,_) in enumerate(KP.items()):
                    pt=kpts.get(name)
                    if pt: kp_list.append({
                        "name":name,"x":round(pt[0],4),"y":round(pt[1],4),
                        "part":part_of(name),"idx":i+1
                    })
                for (a,b) in SKELETON:
                    pa,pb=kpts.get(a),kpts.get(b)
                    if pa and pb:
                        conn_list.append({
                            "x1":round(pa[0],4),"y1":round(pa[1],4),
                            "x2":round(pb[0],4),"y2":round(pb[1],4),
                            "part":part_of(a)
                        })
            elif visible > 0:
                reject = f"Only {visible}/20 KP"

            # ── Draw fence + skeleton onto frame
            draw_fence_on_frame(frame)
            if human:
                draw_skeleton(frame, kpts, breach, shape_s)

            # ── Normal capture logic
            conf_cnt = conf_cnt+1 if human else 0
            saved=False; cap_b64=None; cap_fname=None
            now=time.time()
            if conf_cnt>=CONFIRM_FRAMES and now-last_cap>=CAPTURE_COOLDOWN:
                ts=datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:20]
                cap_fname=f"human_{ts}.jpg"
                cv2.imwrite(os.path.join(CAPTURES_DIR,cap_fname),frame,
                            [cv2.IMWRITE_JPEG_QUALITY,90])
                _,buf=cv2.imencode(".jpg",frame,[cv2.IMWRITE_JPEG_QUALITY,85])
                cap_b64=base64.b64encode(buf).decode()
                last_cap=now; conf_cnt=0; total+=1; saved=True
                cap_list.insert(0,cap_fname)
                if len(cap_list)>50: cap_list=cap_list[:50]
                print(f"[CAPTURE #{total}] {cap_fname}")

            # ── Breach capture logic (separate from normal)
            breach_saved=False; breach_b64=None; breach_fname=None
            if human and breach and now-last_breach_cap>=BREACH_COOLDOWN:
                ts=datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:20]
                breach_fname=f"BREACH_{ts}.jpg"
                cv2.imwrite(os.path.join(CAPTURES_DIR,breach_fname),frame,
                            [cv2.IMWRITE_JPEG_QUALITY,95])
                _,buf2=cv2.imencode(".jpg",frame,[cv2.IMWRITE_JPEG_QUALITY,90])
                breach_b64=base64.b64encode(buf2).decode()
                last_breach_cap=now; total_breaches+=1; breach_saved=True
                breach_list.insert(0,breach_fname)
                if len(breach_list)>30: breach_list=breach_list[:30]
                print(f"[BREACH #{total_breaches}] {breach_fname}")

            # JPEG encode for stream
            _,jpeg=cv2.imencode(".jpg",frame,[cv2.IMWRITE_JPEG_QUALITY,STREAM_QUALITY])

            with _lock:
                shared["frame_jpeg"]      = jpeg.tobytes()
                shared["human_detected"]  = human
                shared["breach_detected"] = breach
                shared["shape_score"]     = round(shape_s,3)
                shared["skin_score"]      = round(skin_s,3)
                shared["motion_score"]    = round(min(1.0,motion_score/0.08),3)
                shared["kp_visible"]      = visible
                shared["fps"]             = round(fps_val,1)
                shared["total_captures"]  = total
                shared["total_breaches"]  = total_breaches
                shared["reject_reason"]   = reject
                shared["keypoints"]       = kp_list
                shared["connections"]     = conn_list
                shared["captures_list"]   = cap_list
                shared["breach_list"]     = breach_list
                shared["person_side"]     = person_side
                if saved: shared["last_capture_b64"]=cap_b64

            # Emit payload
            payload = {k:shared[k] for k in [
                "human_detected","breach_detected","shape_score","skin_score",
                "motion_score","kp_visible","fps","total_captures","total_breaches",
                "reject_reason","keypoints","connections","captures_list",
                "breach_list","person_side"]}
            if saved:
                payload["new_capture_b64"]    = cap_b64
                payload["new_capture_fname"]  = cap_fname
            if breach_saved:
                payload["new_breach_b64"]     = breach_b64
                payload["new_breach_fname"]   = breach_fname
            sio.emit("detection_data", payload)

        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"[ERROR] {e}"); traceback.print_exc(); time.sleep(0.05)

    cap.release(); landmarker.close()
    with _lock: shared["running"]=False

# ══════════════════════════════════════════════════════════════════
#  SOCKETIO — receive fence updates from browser
# ══════════════════════════════════════════════════════════════════
@sio.on("update_fence")
def on_update_fence(data):
    """
    Browser sends: {x1,y1,x2,y2, safe_side, enabled, sensitivity}
    All coords normalized 0–1.
    """
    with fence_lock:
        if "x1"          in data: fence_state["x1"]          = float(data["x1"])
        if "y1"          in data: fence_state["y1"]          = float(data["y1"])
        if "x2"          in data: fence_state["x2"]          = float(data["x2"])
        if "y2"          in data: fence_state["y2"]          = float(data["y2"])
        if "safe_side"   in data: fence_state["safe_side"]   = data["safe_side"]
        if "enabled"     in data: fence_state["enabled"]     = bool(data["enabled"])
        if "sensitivity" in data: fence_state["sensitivity"] = data["sensitivity"]
    print(f"[FENCE] Updated → {fence_state}")
    # Broadcast updated fence to all clients
    sio.emit("fence_updated", fence_state)

@sio.on("get_fence")
def on_get_fence():
    with fence_lock:
        sio.emit("fence_updated", dict(fence_state))

@sio.on("connect")
def on_connect():
    print("[WS] Client connected")
    with fence_lock:
        sio.emit("fence_updated", dict(fence_state))

# ══════════════════════════════════════════════════════════════════
#  FLASK ROUTES
# ══════════════════════════════════════════════════════════════════
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/video_feed")
def video_feed():
    def gen():
        while True:
            with _lock: jpeg = shared["frame_jpeg"]
            if jpeg:
                yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpeg + b"\r\n"
            time.sleep(0.033)
    return Response(gen(), mimetype="multipart/x-mixed-replace; boundary=frame")

# ══════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    t = threading.Thread(target=detection_loop, daemon=True)
    t.start()
    print("[SERVER] Virtual Fence System → http://0.0.0.0:5000")
    sio.run(app, host="0.0.0.0", port=5000, debug=False)
